"use client"

import { Menu } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ModeToggle } from "@/components/mode-toggle"

interface MobileHeaderProps {
  currentStep: number
  totalSteps: number
}

export function MobileHeader({ currentStep, totalSteps }: MobileHeaderProps) {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <div className="flex flex-col gap-4 py-4">
                <h2 className="text-lg font-semibold">Excel Editor</h2>
                <nav className="flex flex-col gap-2">
                  <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                    Home
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                    Templates
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                    Help
                  </a>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
          <h1 className="text-lg font-semibold">Excel Editor</h1>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center text-sm text-muted-foreground">
            Step {currentStep + 1} of {totalSteps}
          </div>
          <ModeToggle />
        </div>
      </div>
      <div
        className="md:hidden h-1 bg-gradient-to-r from-emerald-500 to-emerald-700"
        style={{
          width: `${((currentStep + 1) / totalSteps) * 100}%`,
          transition: "width 0.3s ease-in-out",
        }}
      />
    </header>
  )
}
